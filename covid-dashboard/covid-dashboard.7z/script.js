import Main from './src/components/main/Main';

const main = new Main();
main.init().then((item) => item);
alert('По возможности, пожалуйста, проверьте в последний день кросс-чека. Задание в тему заболевания, которое подкосило')
